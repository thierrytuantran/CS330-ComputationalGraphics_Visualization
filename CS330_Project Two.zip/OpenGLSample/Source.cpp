﻿#include <iostream>
#include <cstdlib>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "camera.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h" // For loading textures

using namespace std;

/* Shader program Macro */
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// Unnamed namespace
namespace {
    const char* const WINDOW_TITLE = "ThierryTran_Project Two";
    const int STRIDE = 7;
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    struct GLMesh {
        GLuint vao;
        GLuint ebo;
        GLuint vbos[2];
        GLuint nIndices;
        GLuint vbo;         // Handle for the vertex buffer object
        GLuint nVertices;
    };

    GLFWwindow* gWindow = nullptr;
    GLMesh gCylinder;
    GLMesh gCone;

    GLMesh gPlaneMesh;
    GLMesh gTVMesh;
    GLMesh gLegMesh;
    GLMesh gDonutMesh;
    GLuint gProgramId;
    GLMesh soccerBall;

    Camera gCamera(glm::vec3(0.0f, 0.0f, 3.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;
    bool isPerspective = true;
    // timing
    float gDeltaTime = 0.0f; // Time between current frame and last frame
    float gLastFrame = 0.0f;

}


// Vertex Shader
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position;
layout(location = 1) in vec3 normal;
layout(location = 2) in vec2 texCoord;

out vec2 TexCoord;
out vec3 FragPos;
out vec3 Normal;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main() {
    gl_Position = projection * view * model * vec4(position, 1.0f);
    FragPos = vec3(model * vec4(position, 6.5f));
    Normal = mat3(transpose(inverse(model))) * normal;
    TexCoord = texCoord;
}
);

// Fragment Shader
const GLchar* fragmentShaderSource = GLSL(440,
    in vec2 TexCoord;
in vec3 FragPos;
in vec3 Normal;

out vec4 fragmentColor;

uniform sampler2D ourTexture;
uniform vec3 lightPos1; // Position of light 1
uniform vec3 lightColor1; // Color of light 1
uniform vec3 lightPos2; // Position of light 2
uniform vec3 lightColor2; // Color of light 2
uniform vec3 viewPos; // Camera position
uniform vec3 objectColor; // Color of the object

void main() {
    // Ambient
    float ambientStrength = 0.1;
    vec3 ambient = ambientStrength * (lightColor1 + lightColor2);

    // Diffuse light 1
    vec3 norm = normalize(Normal);
    vec3 lightDir1 = normalize(lightPos1 - FragPos);
    float diff1 = max(dot(norm, lightDir1), 0.0);
    vec3 diffuse1 = diff1 * lightColor1;

    // Diffuse light 2
    vec3 lightDir2 = normalize(lightPos2 - FragPos);
    float diff2 = max(dot(norm, lightDir2), 0.0);
    vec3 diffuse2 = diff2 * lightColor2;

    // Specular light 1
    float specularStrength = 1.5;
    vec3 viewDir = normalize(viewPos - FragPos);
    vec3 reflectDir1 = reflect(-lightDir1, norm);
    float spec1 = pow(max(dot(viewDir, reflectDir1), 0.0), 32);
    vec3 specular1 = specularStrength * spec1 * lightColor1;

    // Specular light 2
    vec3 reflectDir2 = reflect(-lightDir2, norm);
    float spec2 = pow(max(dot(viewDir, reflectDir2), 0.0), 32);
    vec3 specular2 = specularStrength * spec2 * lightColor2;

    vec3 result = (ambient + diffuse1 + diffuse2 + specular1 + specular2) * objectColor;
    fragmentColor = (texture(ourTexture, TexCoord) * vec4(result, 1.0));
}
);

GLuint LoadTexture(const char* filename) {
    int width, height, nrChannels;
    unsigned char* data = stbi_load(filename, &width, &height, &nrChannels, 0);
    if (!data) {
        std::cerr << "Failed to load texture" << std::endl;
        return 0;
    }

    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    // Set the texture wrapping/filtering options
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Specify texture format based on nrChannels
    GLenum format;
    if (nrChannels == 1)
        format = GL_RED;
    else if (nrChannels == 3)
        format = GL_RGB;
    else if (nrChannels == 4)
        format = GL_RGBA;

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);

    stbi_image_free(data);
    return textureID;
}


// Function prototypes
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);

void UCreateCylinder(GLMesh& mesh, int numSides, float radius, float height);
void UCreateCone(GLMesh& mesh, int numSides, float radius, float height);
void URenderCylinder(GLuint programId, GLMesh& cylinderMesh, glm::mat4 modelMatrix);
void URenderCone(GLuint programId, GLMesh& coneMesh, glm::mat4 modelMatrix);
// Function declarations
void UCreateTV(GLMesh& mesh);
void URenderTV(GLuint programId, GLMesh& TVMesh, glm::mat4 modelMatrix, GLuint textureId);
void UCreateLegs(GLMesh& mesh);
void URenderLegs(GLuint programId, GLMesh& legMesh, glm::vec3 tvPosition, float tvHeight, float legHeight);
void UCreateSphere(GLMesh& mesh, int sectorCount, int stackCount, float radius);
void URenderSphere(GLuint programId, GLMesh& mesh, glm::mat4 modelMatrix);
void UCreateDonut(GLMesh& mesh, float outerRadius, float innerRadius, int nsides, int nrings);
void URenderDonut(GLuint programId, GLMesh& DonutMesh, glm::mat4 modelMatrix, GLuint textureId);

void UCreatePlane(GLMesh& mesh);
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
void UDestroyMesh(GLMesh& mesh);

int main(int argc, char* argv[]) {
    // Initialize GLFW and configure the window
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Enable depth testing for 3D rendering
    glEnable(GL_DEPTH_TEST);

    // Load textures
    GLuint cylinderTexture = LoadTexture("../OpenGLSample/resources/textures/stripe.jpg");
    GLuint coneTexture = LoadTexture("../OpenGLSample/resources/textures/pattern.jpg");
    GLuint planeTexture = LoadTexture("../OpenGLSample/resources/textures/images.jpg");
    GLuint TVTexture = LoadTexture("../OpenGLSample/resources/textures/TV.jpg");
    GLuint soccerBallTexture = LoadTexture("../OpenGLSample/resources/textures/soccerball.jpg");
    GLuint DonutTexture = LoadTexture("../OpenGLSample/resources/textures/donut.jpg");
    // Create shapes
    float cylinderHeight = 2.0f;
    float cylinderRadius = 0.1f;
    float coneHeight = 0.5f;
    UCreateCylinder(gCylinder, 50, cylinderRadius, cylinderHeight);
    UCreateCone(gCone, 50, cylinderRadius, coneHeight);
    UCreatePlane(gPlaneMesh);
    UCreateTV(gTVMesh);
    UCreateLegs(gLegMesh);
    // Create shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;
    UCreateSphere(soccerBall, 36, 18, 1.0f);
    float outerRadius = 1.0f; // Outer radius of the Donut
    float innerRadius = 0.3f; // Inner radius of the Donut
    int nsides = 30; // Number of sides for each ring
    int nrings = 30; // Number of rings that make up the Donut
    UCreateDonut(gDonutMesh, outerRadius, innerRadius, nsides, nrings);
    // Main rendering loop
    while (!glfwWindowShouldClose(gWindow)) {
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;
        UProcessInput(gWindow);

        // Clear the color and depth buffers
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glm::mat4 view = gCamera.GetViewMatrix();
        glm::mat4 projection;
        if (isPerspective) {
            projection = glm::perspective(glm::radians(gCamera.Zoom),
                (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT,
                0.1f, 100.0f);
        }
        else {
            float aspect = (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT;
            projection = glm::ortho(-aspect, aspect, -1.0f, 1.0f, 0.1f, 100.0f);
        }
        glUseProgram(gProgramId);
        glUniformMatrix4fv(glGetUniformLocation(gProgramId, "view"), 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(glGetUniformLocation(gProgramId, "projection"), 1, GL_FALSE, glm::value_ptr(projection));

        //  light setup
        glm::vec3 lightPos1 = glm::vec3(1.2f, 1.0f, 2.0f);
        glm::vec3 lightColor1 = glm::vec3(1.0f, 1.0f, 1.0f); // White light
        glm::vec3 lightPos2 = glm::vec3(-2.0f, -1.0f, -3.0f);
        glm::vec3 lightColor2 = glm::vec3(1.0f, 1.0f, 1.0f); // Red light
        glm::vec3 objectColor(1.0f, 1.0f, 1.0f);
        // Set uniforms for lighting
        glUniform3fv(glGetUniformLocation(gProgramId, "lightPos1"), 1, glm::value_ptr(lightPos1));
        glUniform3fv(glGetUniformLocation(gProgramId, "lightColor1"), 1, glm::value_ptr(lightColor1));
        glUniform3fv(glGetUniformLocation(gProgramId, "lightPos2"), 1, glm::value_ptr(lightPos2));
        glUniform3fv(glGetUniformLocation(gProgramId, "lightColor2"), 1, glm::value_ptr(lightColor2));
        glUniform3fv(glGetUniformLocation(gProgramId, "viewPos"), 1, glm::value_ptr(gCamera.Position));
        glUniform3fv(glGetUniformLocation(gProgramId, "objectColor"), 1, glm::value_ptr(objectColor));

        // Render Cylinder
        glm::mat4 cylinderModelMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, (cylinderHeight / 2 - 0.5f) - 0.1f, 0.0f));
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, cylinderTexture);
        glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(cylinderModelMatrix));
        URenderCylinder(gProgramId, gCylinder, cylinderModelMatrix);

        // Render Cone
        glm::mat4 coneModelMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, (cylinderHeight - 0.5f + coneHeight / 2) - 0.1f, 0.0f));
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, coneTexture);
        glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(coneModelMatrix));
        URenderCone(gProgramId, gCone, coneModelMatrix);

        // Render Plane
        glm::mat4 planeModelMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.5f, 0.0f));
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, planeTexture);
        glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(planeModelMatrix));
        glBindVertexArray(gPlaneMesh.vao);
        glDrawArrays(GL_TRIANGLES, 0, gPlaneMesh.nVertices);
        glBindVertexArray(0);


        // Render TV
        glm::mat4 TVModelMatrix = glm::mat4(1.0f);
        TVModelMatrix = glm::translate(TVModelMatrix, glm::vec3(0.8f, 0.08f, 0.0f)); // Move to the right of the pencil
        TVModelMatrix = glm::scale(TVModelMatrix, glm::vec3(1.0f, 1.0f, 1.0f)); // Keep the scale as is or adjust as needed
        URenderTV(gProgramId, gTVMesh, TVModelMatrix, TVTexture);

        // Render legs
        glm::vec3 tvPosition = glm::vec3(0.8f, 0.31f, 0.0f); //  TV position
        float tvHeight = 0.75f; // The height of the TV
        float legHeight = 0.4f; // The height of the legs
        URenderLegs(gProgramId, gLegMesh, tvPosition, tvHeight, legHeight);

        // Render the soccer ball
        glm::mat4 soccerBallModelMatrix = glm::mat4(1.0f);
        soccerBallModelMatrix = glm::translate(soccerBallModelMatrix, glm::vec3(0.0f, -0.2f, 0.3f)); // Position the soccer ball
        soccerBallModelMatrix = glm::scale(soccerBallModelMatrix, glm::vec3(0.3f, 0.3f, 0.3f));
        soccerBallModelMatrix = glm::rotate(soccerBallModelMatrix, glm::radians(180.0f), glm::vec3(-0.06f, 0.5f, 0.6f));
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, soccerBallTexture);
        glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(soccerBallModelMatrix));
        URenderSphere(gProgramId, soccerBall, soccerBallModelMatrix);
        
        // Render Donut
        glm::mat4 DonutModelMatrix = glm::mat4(1.0f);
        DonutModelMatrix = glm::translate(DonutModelMatrix, glm::vec3(-1.0f, 0.2f, -1.0f)); // Move the Donut to the desired position
        DonutModelMatrix = glm::scale(DonutModelMatrix, glm::vec3(0.5f)); // Scale if needed
        URenderDonut(gProgramId, gDonutMesh, DonutModelMatrix, DonutTexture);

        glfwSwapBuffers(gWindow);
        glfwPollEvents();
    }
    // Release mesh data
    UDestroyMesh(gPlaneMesh);
    UDestroyMesh(gCylinder);
    UDestroyMesh(gCone);
    UDestroyMesh(gLegMesh);
    UDestroyMesh(gTVMesh);
    UDestroyMesh(gDonutMesh);
    UDestroyShaderProgram(gProgramId);

    // Terminate GLFW
    glfwTerminate();
    return EXIT_SUCCESS;
}



bool UInitialize(int argc, char* argv[], GLFWwindow** window) {
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, nullptr, nullptr);
    if (*window == nullptr) {
        cerr << "Failed to create GLFW window" << endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;
    return true;
}

void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
        isPerspective = !isPerspective; // Toggle projection mode
    }
}
void UResizeWindow(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}

// glfw: Whenever the mouse moves, this callback is called.
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // Reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: Whenever the mouse scroll wheel scrolls, this callback is called.
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    cout << "Mouse wheel (" << xoffset << ", " << yoffset << ")" << endl;
}

// glfw: Handle mouse button events.
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}

//void UProcessInput(GLFWwindow* window) {
 //   if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
  //      glfwSetWindowShouldClose(window, true);
//

void UCreateCylinder(GLMesh& mesh, int numSides, float radius, float height) {
    const float PI = 3.1415926f;
    const float angleStep = 2 * PI / numSides;

    vector<float> vertices;
    vector<GLushort> indices;

    // Create vertices for the side of the cylinder
    for (int i = 0; i < numSides; ++i) {
        float x1 = radius * cos(angleStep * i);
        float z1 = radius * sin(angleStep * i);
        float x2 = radius * cos(angleStep * (i + 1));
        float z2 = radius * sin(angleStep * (i + 1));

        // Bottom vertex
        vertices.push_back(x1);
        vertices.push_back(-height / 2);
        vertices.push_back(z1);
        vertices.push_back(0.0f);
        vertices.push_back(0.0f);
        vertices.push_back(1.0f);
        vertices.push_back(1.0f);

        // Top vertex
        vertices.push_back(x2);
        vertices.push_back(height / 2);
        vertices.push_back(z2);
        vertices.push_back(0.0f);
        vertices.push_back(0.0f);
        vertices.push_back(1.0f);
        vertices.push_back(1.0f);
    }

    // Create indices for the side of the cylinder
    for (int i = 0; i < numSides; ++i) {
        indices.push_back(i * 2);
        indices.push_back(i * 2 + 1);
        indices.push_back((i * 2 + 2) % (numSides * 2));

        indices.push_back((i * 2 + 2) % (numSides * 2));
        indices.push_back(i * 2 + 1);
        indices.push_back((i * 2 + 3) % (numSides * 2));
    }

    // Create vertices for the bottom and top faces of the cylinder
    for (int i = 0; i < numSides; ++i) {
        float x1 = radius * cos(angleStep * i);
        float z1 = radius * sin(angleStep * i);
        float x2 = radius * cos(angleStep * (i + 1));
        float z2 = radius * sin(angleStep * (i + 1));

        // Bottom vertex
        vertices.push_back(x1);
        vertices.push_back(-height / 2);
        vertices.push_back(z1);
        vertices.push_back(0.0f);
        vertices.push_back(0.0f);
        vertices.push_back(1.0f);
        vertices.push_back(1.0f);

        // Top vertex
        vertices.push_back(x2);
        vertices.push_back(-height / 2);
        vertices.push_back(z2);
        vertices.push_back(0.0f);
        vertices.push_back(0.0f);
        vertices.push_back(1.0f);
        vertices.push_back(1.0f);
    }

    // Create indices for the bottom and top faces of the cylinder
    for (int i = 0; i < numSides; ++i) {
        int baseIndex = numSides * 4;
        indices.push_back(baseIndex + i * 2);
        indices.push_back(baseIndex + (i * 2 + 2) % (numSides * 2));
        indices.push_back(baseIndex + i * 2 + 1);

        indices.push_back(baseIndex + i * 2 + 1);
        indices.push_back(baseIndex + (i * 2 + 2) % (numSides * 2));
        indices.push_back(baseIndex + (i * 2 + 3) % (numSides * 2));
    }

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);

    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float) * vertices.size(), &vertices[0], GL_STATIC_DRAW);

    mesh.nIndices = indices.size();
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLushort) * mesh.nIndices, &indices[0], GL_STATIC_DRAW);

    GLint stride = sizeof(float) * STRIDE;
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * 3));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * 7));
    glEnableVertexAttribArray(2);
}

void UCreateCone(GLMesh& mesh, int numSides, float radius, float height) {
    const float PI = 3.1415926f;
    const float angleStep = 2 * PI / numSides;

    vector<float> vertices;
    vector<GLushort> indices;

    // Create vertices for the base of the cone
    vertices.push_back(0.0f);
    vertices.push_back(-height / 2);
    vertices.push_back(0.0f);
    vertices.push_back(0.0f);
    vertices.push_back(0.0f);
    vertices.push_back(1.0f);
    vertices.push_back(1.0f);

    for (int i = 0; i < numSides; ++i) {
        float x = radius * cos(angleStep * i);
        float z = radius * sin(angleStep * i);

        vertices.push_back(x);
        vertices.push_back(-height / 2);
        vertices.push_back(z);
        vertices.push_back(0.0f);
        vertices.push_back(0.0f);
        vertices.push_back(1.0f);
        vertices.push_back(1.0f);
    }

    // Create indices for the base of the cone
    for (int i = 1; i < numSides + 1; ++i) {
        indices.push_back(0);
        indices.push_back(i);
        indices.push_back((i % numSides) + 1);
    }

    // Create vertices for the sides of the cone
    for (int i = 0; i < numSides; ++i) {
        float x1 = radius * cos(angleStep * i);
        float z1 = radius * sin(angleStep * i);
        float x2 = 0.0f;
        float z2 = 0.0f;

        vertices.push_back(x1);
        vertices.push_back(-height / 2);
        vertices.push_back(z1);
        vertices.push_back(0.0f);
        vertices.push_back(0.0f);
        vertices.push_back(1.0f);
        vertices.push_back(1.0f);

        vertices.push_back(x2);
        vertices.push_back(height / 2);
        vertices.push_back(z2);
        vertices.push_back(0.0f);
        vertices.push_back(0.0f);
        vertices.push_back(1.0f);
        vertices.push_back(1.0f);
    }

    // Create indices for the sides of the cone
    for (int i = 1; i <= numSides; ++i) {
        int baseIndex = (numSides + 1);
        indices.push_back(baseIndex + (i - 1) * 2);
        indices.push_back(baseIndex + (i % numSides) * 2);
        indices.push_back(baseIndex + (i % numSides) * 2 + 1);

        indices.push_back(baseIndex + (i - 1) * 2 + 1);
        indices.push_back(baseIndex + (i - 1) * 2);
        indices.push_back(baseIndex + (i % numSides) * 2 + 1);
    }

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);

    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float) * vertices.size(), &vertices[0], GL_STATIC_DRAW);

    mesh.nIndices = indices.size();
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLushort) * mesh.nIndices, &indices[0], GL_STATIC_DRAW);

    GLint stride = sizeof(float) * STRIDE;
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * 3));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * 7));
    glEnableVertexAttribArray(2);
}
void UCreatePlane(GLMesh& mesh) {
    GLfloat verts[] = {
        // Vertex Positions    // Colors (r,g,b,a)   // Texture Coordinates
        -2.0f, 0.0f, -2.0f,    0.5f, 0.35f, 0.05f, 1.0f,   0.0f, 0.0f, // Bottom-left
         2.0f, 0.0f, -2.0f,    0.5f, 0.35f, 0.05f, 1.0f,   1.0f, 0.0f, // Bottom-right
         2.0f, 0.0f,  2.0f,    0.5f, 0.35f, 0.05f, 1.0f,   1.0f, 1.0f, // Top-right

        -2.0f, 0.0f, -2.0f,    0.5f, 0.35f, 0.05f, 1.0f,   0.0f, 0.0f, // Bottom-left
         2.0f, 0.0f,  2.0f,    0.5f, 0.35f, 0.05f, 1.0f,   1.0f, 1.0f, // Top-right
        -2.0f, 0.0f,  2.0f,    0.5f, 0.35f, 0.05f, 1.0f,   0.0f, 1.0f, // Top-left
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerColor = 4;
    const GLuint floatsPerTexCoord = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerColor + floatsPerTexCoord));

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerColor + floatsPerTexCoord);

    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerTexCoord, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);
}

void UCreateTV(GLMesh& mesh) {
    // TV dimensions
    float tvWidth = 1.0f; 
    float tvHeight = 0.75f;
    float tvDepth = 0.1f; 

    // Define the vertices and normals for the TV
    GLfloat vertices[] = {
        // Positions            // Normals           // Texture Coords
        // Front face
        -tvWidth / 2, -tvHeight / 2, tvDepth / 2, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,
         tvWidth / 2, -tvHeight / 2, tvDepth / 2, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f,
         tvWidth / 2,  tvHeight / 2, tvDepth / 2, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,
        -tvWidth / 2,  tvHeight / 2, tvDepth / 2, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f,
        // Back face
        -tvWidth / 2, -tvHeight / 2, -tvDepth / 2, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,
         tvWidth / 2, -tvHeight / 2, -tvDepth / 2, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,
         tvWidth / 2,  tvHeight / 2, -tvDepth / 2, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,
        -tvWidth / 2,  tvHeight / 2, -tvDepth / 2, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,
        // Top face
        -tvWidth / 2,  tvHeight / 2, -tvDepth / 2, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,
        -tvWidth / 2,  tvHeight / 2,  tvDepth / 2, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,
         tvWidth / 2,  tvHeight / 2,  tvDepth / 2, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,
         tvWidth / 2,  tvHeight / 2, -tvDepth / 2, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f,
         // Bottom face
        -tvWidth / 2, -tvHeight / 2, -tvDepth / 2, 0.0f, -1.0f, 0.0f, 1.0f, 1.0f,
        -tvWidth / 2, -tvHeight / 2,  tvDepth / 2, 0.0f, -1.0f, 0.0f, 0.0f, 1.0f,
         tvWidth / 2, -tvHeight / 2,  tvDepth / 2, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f,
         tvWidth / 2, -tvHeight / 2, -tvDepth / 2, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f,
          // Right face
         tvWidth / 2, -tvHeight / 2, -tvDepth / 2, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f,
         tvWidth / 2,  tvHeight / 2, -tvDepth / 2, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f,
         tvWidth / 2,  tvHeight / 2,  tvDepth / 2, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f,
         tvWidth / 2, -tvHeight / 2,  tvDepth / 2, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f,
           // Left face
         -tvWidth / 2, -tvHeight / 2, -tvDepth / 2, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f,
         -tvWidth / 2, -tvHeight / 2,  tvDepth / 2, -1.0f, 0.0f, 0.0f, 0.0f, 0.0f,
         -tvWidth / 2,  tvHeight / 2,  tvDepth / 2, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f,
         -tvWidth / 2,  tvHeight / 2, -tvDepth / 2, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f,
    };

    // Define the indices for drawing the triangles
    GLushort indices[] = {
        // Front face
        0, 1, 2, 0, 2, 3,
        // Back face
        4, 5, 6, 4, 6, 7,
        // Top face
        8, 9, 10, 8, 10, 11,
        // Bottom face
        12, 13, 14, 12, 14, 15,
        // Right face
        16, 17, 18, 16, 18, 19,
        // Left face
        20, 21, 22, 20, 22, 23,
    };

    // Create vertex array and buffers
    glGenVertexArrays(1, &mesh.vao);
    glGenBuffers(1, &mesh.vbo);
    glGenBuffers(1, &mesh.ebo);

    glBindVertexArray(mesh.vao);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)0);
    glEnableVertexAttribArray(0);
    // Normal attribute
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(1);
    // Texture coord attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(6 * sizeof(GLfloat)));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0); // Unbind VAO

    mesh.nVertices = sizeof(vertices) / (8 * sizeof(GLfloat)); // 8 = 3 for position + 3 for normal + 2 for texture
    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);

}

void UCreateLegs(GLMesh& mesh) {
     float legWidth = 0.05f; // Leg width
     float legHeight = 0.4f; // Leg height
     float legDepth = 0.05f; // Leg depth
    // Vertices for a simple box-shaped leg
    GLfloat vertices[] = {
        // Positions          // Normals           // Texture Coords
        // Front face
        -legWidth, -legHeight,  legDepth,  0.0f, 0.0f, 1.0f,  0.0f, 0.0f,
         legWidth, -legHeight,  legDepth,  0.0f, 0.0f, 1.0f,  1.0f, 0.0f,
         legWidth,  0.0f,       legDepth,  0.0f, 0.0f, 1.0f,  1.0f, 1.0f,
        -legWidth,  0.0f,       legDepth,  0.0f, 0.0f, 1.0f,  0.0f, 1.0f,
        // Back face
        -legWidth, -legHeight, -legDepth,  0.0f, 0.0f, -1.0f,  1.0f, 0.0f,
         legWidth, -legHeight, -legDepth,  0.0f, 0.0f, -1.0f,  0.0f, 0.0f,
         legWidth,  0.0f,      -legDepth,  0.0f, 0.0f, -1.0f,  0.0f, 1.0f,
        -legWidth,  0.0f,      -legDepth,  0.0f, 0.0f, -1.0f,  1.0f, 1.0f,
        // Top face
        -legWidth,  0.0f,      -legDepth,  0.0f, 1.0f, 0.0f,  0.0f, 1.0f,
         legWidth,  0.0f,      -legDepth,  0.0f, 1.0f, 0.0f,  1.0f, 1.0f,
         legWidth,  0.0f,       legDepth,  0.0f, 1.0f, 0.0f,  1.0f, 0.0f,
        -legWidth,  0.0f,       legDepth,  0.0f, 1.0f, 0.0f,  0.0f, 0.0f,
        // Bottom face
        -legWidth, -legHeight, -legDepth,  0.0f, -1.0f, 0.0f,  0.0f, 1.0f,
         legWidth, -legHeight, -legDepth,  0.0f, -1.0f, 0.0f,  1.0f, 1.0f,
         legWidth, -legHeight,  legDepth,  0.0f, -1.0f, 0.0f,  1.0f, 0.0f,
        -legWidth, -legHeight,  legDepth,  0.0f, -1.0f, 0.0f,  0.0f, 0.0f,
        // Right face
         legWidth, -legHeight, -legDepth,  1.0f, 0.0f, 0.0f,  0.0f, 0.0f,
         legWidth,  0.0f,      -legDepth,  1.0f, 0.0f, 0.0f,  1.0f, 0.0f,
         legWidth,  0.0f,       legDepth,  1.0f, 0.0f, 0.0f,  1.0f, 1.0f,
         legWidth, -legHeight,  legDepth,  1.0f, 0.0f, 0.0f,  0.0f, 1.0f,
         // Left face
         -legWidth, -legHeight, -legDepth, -1.0f, 0.0f, 0.0f,  1.0f, 0.0f,
         -legWidth,  0.0f,      -legDepth, -1.0f, 0.0f, 0.0f,  0.0f, 0.0f,
         -legWidth,  0.0f,       legDepth, -1.0f, 0.0f, 0.0f,  0.0f, 1.0f,
         -legWidth, -legHeight,  legDepth, -1.0f, 0.0f, 0.0f,  1.0f, 1.0f,
    };

    GLushort indices[] = {
        // Front face
        0, 1, 2, 2, 3, 0,
        // Back face
        4, 5, 6, 6, 7, 4,
        // Top face
        8, 9, 10, 10, 11, 8,
        // Bottom face
        12, 13, 14, 14, 15, 12,
        // Right face
        16, 17, 18, 18, 19, 16,
        // Left face
        20, 21, 22, 22, 23, 20,
    };

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glGenBuffers(1, &mesh.ebo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Set the vertex attribute pointers
    // Vertex Positions
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)0);
    // Vertex Normals
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
    // Vertex Texture Coords
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(6 * sizeof(GLfloat)));

    glBindVertexArray(0); // Unbind VAO

    mesh.nIndices = sizeof(indices) / sizeof(GLushort);
}

void UCreateSphere(GLMesh& mesh, int sectorCount, int stackCount, float radius) {
    std::vector<float> vertices;
    std::vector<unsigned int> indices;

    float x, y, z, xy;                              // vertex position
    float nx, ny, nz, lengthInv = 1.0f / radius;    // vertex normal
    float s, t;                                     // vertex texCoord

    float sectorStep = 2 * M_PI / sectorCount;
    float stackStep = M_PI / stackCount;
    float sectorAngle, stackAngle;

    for (int i = 0; i <= stackCount; ++i) {
        stackAngle = M_PI / 2 - i * stackStep;        // starting from pi/2 to -pi/2
        xy = radius * cosf(stackAngle);             // r * cos(u)
        z = radius * sinf(stackAngle);              // r * sin(u)

        // add (sectorCount+1) vertices per stack
       
        for (int j = 0; j <= sectorCount; ++j) {
            sectorAngle = j * sectorStep;           // starting from 0 to 2pi

            // vertex position (x, y, z)
            x = xy * cosf(sectorAngle);             // r * cos(u) * cos(v)
            y = xy * sinf(sectorAngle);             // r * cos(u) * sin(v)
            vertices.push_back(x);
            vertices.push_back(y);
            vertices.push_back(z);

            // normalized vertex normal (nx, ny, nz)
            nx = x * lengthInv;
            ny = y * lengthInv;
            nz = z * lengthInv;
            vertices.push_back(nx);
            vertices.push_back(ny);
            vertices.push_back(nz);

            // vertex tex coord (s, t) range between [0, 1]
            s = (float)j / sectorCount;
            t = (float)i / stackCount;
            vertices.push_back(s);
            vertices.push_back(t);
        }
    }

    // generate CCW index list of sphere triangles
    int k1, k2;
    for (int i = 0; i < stackCount; ++i) {
        k1 = i * (sectorCount + 1);     // beginning of current stack
        k2 = k1 + sectorCount + 1;      // beginning of next stack

        for (int j = 0; j < sectorCount; ++j, ++k1, ++k2) {
            // 2 triangles per sector excluding first and last stacks
            // k1 => k2 => k1+1
            if (i != 0) {
                indices.push_back(k1);
                indices.push_back(k2);
                indices.push_back(k1 + 1);
            }

            // k1+1 => k2 => k2+1
            if (i != (stackCount - 1)) {
                indices.push_back(k1 + 1);
                indices.push_back(k2);
                indices.push_back(k2 + 1);
            }
        }
    }

    // Create buffers/arrays
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), &vertices[0], GL_STATIC_DRAW);

    glGenBuffers(1, &mesh.ebo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), &indices[0], GL_STATIC_DRAW);

    // Set the vertex attribute pointers
    // Vertex Positions
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    // Vertex Normals
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    // Vertex Texture Coords
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));

    glBindVertexArray(0);

    mesh.nVertices = vertices.size() / 8; // Each vertex has 8 attributes
    mesh.nIndices = indices.size();
}
void UCreateDonut(GLMesh& mesh, float outerRadius, float innerRadius, int nsides, int nrings) {
    // Donut vertices and indices
    std::vector<float> vertices;
    std::vector<unsigned int> indices;

    // Angle between each side in each ring
    float thetaStep = (2 * M_PI) / nrings;
    float phiStep = (2 * M_PI) / nsides;
    float theta = 0.0f;
    float phi = 0.0f;

    // Generate vertices
    for (int i = 0; i < nrings; ++i) {
        theta = i * thetaStep;
        for (int j = 0; j < nsides; ++j) {
            phi = j * phiStep;

            // Position
            float x = (outerRadius + innerRadius * cos(theta)) * cos(phi);
            float y = (outerRadius + innerRadius * cos(theta)) * sin(phi);
            float z = innerRadius * sin(theta);

            // Normal
            float nx = x - outerRadius * cos(phi);
            float ny = y - outerRadius * sin(phi);
            float nz = z;

            // Normalize normal
            float len = sqrt(nx * nx + ny * ny + nz * nz);
            nx /= len; ny /= len; nz /= len;

            // Texture coordinates
            float s = (float)j / nsides;
            float t = (float)i / nrings;

            vertices.insert(vertices.end(), { x, y, z, nx, ny, nz, s, t });
        }
    }

    // Generate indices
    for (int i = 0; i < nrings; ++i) {
        for (int j = 0; j < nsides; ++j) {
            int first = (i * nsides + j);
            int second = (first + nsides) % (nrings * nsides);

            indices.push_back(first);
            indices.push_back(second);
            indices.push_back((first + 1) % (nrings * nsides));

            indices.push_back(second);
            indices.push_back((second + 1) % (nrings * nsides));
            indices.push_back((first + 1) % (nrings * nsides));
        }
    }

    // Create buffers/arrays
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), &vertices[0], GL_STATIC_DRAW);

    glGenBuffers(1, &mesh.ebo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), &indices[0], GL_STATIC_DRAW);

    // Set the vertex attribute pointers
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0); // Vertex positions
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float))); // Normals
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float))); // Texture coordinates
    glEnableVertexAttribArray(2);

    glBindVertexArray(0); // Unbind VAO

    mesh.nVertices = vertices.size() / 8;
    mesh.nIndices = indices.size();
}
void URenderDonut(GLuint programId, GLMesh& DonutMesh, glm::mat4 modelMatrix, GLuint textureId) {
    // Activate the shader program
    glUseProgram(programId);

    // Pass the model matrix to the shader
    GLint modelLoc = glGetUniformLocation(programId, "model");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

    // Pass the texture to the shader
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textureId);
    glUniform1i(glGetUniformLocation(programId, "ourTexture"), 0);

    // Bind the Donut VAO and draw it
    glBindVertexArray(DonutMesh.vao);
    glDrawElements(GL_TRIANGLES, DonutMesh.nIndices, GL_UNSIGNED_INT, 0);

    // Unbind the VAO
    glBindVertexArray(0);
}

void URenderSphere(GLuint programId, GLMesh& mesh, glm::mat4 modelMatrix) {
    // Activate the shader program
    glUseProgram(programId);
    GLint modelLoc = glGetUniformLocation(programId, "model");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
    glBindVertexArray(mesh.vao);
    glDrawElements(GL_TRIANGLES, mesh.nIndices, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}


void URenderLegs(GLuint programId, GLMesh& legMesh, glm::vec3 tvPosition, float tvHeight, float legHeight) {
    // Activate the shader program
    glUseProgram(programId);

    // Calculate positions for each leg
    glm::vec3 legOffsets[4] = {
        glm::vec3(-0.4f, -tvHeight / 2 - legHeight / 2, 0.2f), // Front left
        glm::vec3(0.4f, -tvHeight / 2 - legHeight / 2, 0.2f),  // Front right
        glm::vec3(-0.4f, -tvHeight / 2 - legHeight / 2, -0.2f), // Back left
        glm::vec3(0.4f, -tvHeight / 2 - legHeight / 2, -0.2f)  // Back right
    };

    for (auto& offset : legOffsets) {
        glm::mat4 legModelMatrix = glm::translate(glm::mat4(1.0f), tvPosition + offset);
        legModelMatrix = glm::scale(legModelMatrix, glm::vec3(0.05f, legHeight, 0.05f)); // Assuming legWidth and legDepth are 0.05f

        GLint modelLoc = glGetUniformLocation(programId, "model");
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(legModelMatrix));

        glBindVertexArray(legMesh.vao);
        glDrawElements(GL_TRIANGLES, legMesh.nIndices, GL_UNSIGNED_SHORT, 0);
    }

    glBindVertexArray(0);
}

void URenderCylinder(GLuint programId, GLMesh& cylinderMesh, glm::mat4 modelMatrix) {
    // Activate the shader program
    glUseProgram(programId);

    // Set the model matrix uniform
    GLint modelLoc = glGetUniformLocation(programId, "model");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

    // Bind the cylinder's vertex array object and draw it
    glBindVertexArray(cylinderMesh.vao);
    glDrawElements(GL_TRIANGLES, cylinderMesh.nIndices, GL_UNSIGNED_SHORT, 0);
    glBindVertexArray(0);
}

void URenderCone(GLuint programId, GLMesh& coneMesh, glm::mat4 modelMatrix) {
    // Activate the shader program
    glUseProgram(programId);

    // Set the model matrix uniform
    GLint modelLoc = glGetUniformLocation(programId, "model");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));

    // Bind the cone's vertex array object and draw it
    glBindVertexArray(coneMesh.vao);
    glDrawElements(GL_TRIANGLES, coneMesh.nIndices, GL_UNSIGNED_SHORT, 0);
    glBindVertexArray(0);
}
void URenderTV(GLuint programId, GLMesh& TVMesh, glm::mat4 modelMatrix, GLuint textureId) {
    // Activate shader program and pass uniforms
    glUseProgram(programId);
    glUniformMatrix4fv(glGetUniformLocation(programId, "model"), 1, GL_FALSE, glm::value_ptr(modelMatrix));

    // Bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textureId);

    // Render the TV
    glBindVertexArray(TVMesh.vao);
    glDrawElements(GL_TRIANGLES, TVMesh.nIndices, GL_UNSIGNED_SHORT, 0);
    glBindVertexArray(0);
}


bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId) {
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrieve the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attach compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success) {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    // Delete the shader objects
    glDeleteShader(vertexShaderId);
    glDeleteShader(fragmentShaderId);

    return true;
}


void UDestroyShaderProgram(GLuint programId) {
    glDeleteProgram(programId);
}

void UDestroyMesh(GLMesh& mesh) {
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}


